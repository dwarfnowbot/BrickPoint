(function(){document.addEventListener('DOMContentLoaded',function(){
var h=document.getElementById('bpHeader');
function onScroll(){if(h){h.classList.toggle('scrolled',window.scrollY>24);}}
window.addEventListener('scroll',onScroll,{passive:true});onScroll();
});})();
