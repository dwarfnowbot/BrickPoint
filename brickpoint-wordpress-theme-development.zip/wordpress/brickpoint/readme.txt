=== BrickPoint ===
Contributors: brickpoint
Tags: construction, bricks, business, responsive
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Premium construction-materials theme with custom Products, Videos, Projects and Locations. WhatsApp inquiry system. No WooCommerce.

== Installation ==
1. Upload brickpoint.zip via Appearance > Themes > Add New > Upload Theme.
2. Activate the theme.
3. Default product & video categories are created automatically.
4. Set menus under Appearance > Menus (Primary, Footer, Mobile).
5. Configure contact, social links and hero video under Appearance > Customize > BrickPoint.
6. Optionally install Elementor (free) for page editing; Elementor Pro enables Theme Builder header/footer/single templates.
7. Add Products (Products > Add New), Videos, Projects and Locations from the admin menu.

== WhatsApp ==
Set the WhatsApp number under Customize > BrickPoint: Contact. Every product generates a prefilled inquiry message automatically.

== Elementor widgets ==
BrickPoint category: Product Grid, Product Categories, Product Price, WhatsApp Button, Video Grid, Video Card, Project Grid, Location Cards, Social Links.

== Notes ==
No WooCommerce dependency. Project visuals should be labelled illustrative unless verified. Replace demo media with your own bhatta photography.
