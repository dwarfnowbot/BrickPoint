<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$term = get_queried_object();
$banner = $term ? get_term_meta( $term->term_id, 'bp_cat_banner', true ) : '';
$video = $term ? get_term_meta( $term->term_id, 'bp_cat_video', true ) : '';
?>
<div class="bp-pagehead bp-pagehead-img" <?php if ( $banner ) : ?>style="background-image:url('<?php echo esc_url( $banner ); ?>')"<?php endif; ?>><div class="bp-container">
  <h1><?php single_term_title(); ?></h1>
  <?php the_archive_description( '<p>', '</p>' ); ?>
  <?php if ( $term ) : ?><p class="bp-mt"><a class="btn-whatsapp" target="_blank" rel="noopener" href="<?php echo esc_url( bp_whatsapp_url( bp_category_whatsapp_message( $term->name ) ) ); ?>"><?php printf( esc_html__( 'Get %s Quote', 'brickpoint' ), esc_html( $term->name ) ); ?></a></p><?php endif; ?>
</div></div>
<?php if ( $video ) : ?><div class="bp-container bp-section"><video class="bp-cat-video" controls playsinline preload="metadata" src="<?php echo esc_url( $video ); ?>"></video></div><?php endif; ?>
<div class="bp-container bp-section"><div class="bp-grid cols-4">
  <?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/product-card' ); endwhile; ?>
</div><?php brickpoint_pagination(); ?></div>
<?php get_footer(); ?>
