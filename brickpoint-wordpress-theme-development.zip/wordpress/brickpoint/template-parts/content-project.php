<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<article class="bp-card">
  <a class="bp-card-media" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'bp-card' ); ?>
    <span class="bp-illus"><?php echo esc_html( bp_project_status( get_the_ID() ) ); ?></span></a>
  <div class="bp-card-body">
    <p class="bp-eyebrow"><?php echo esc_html( bp_meta( get_the_ID(), '_bpp_location', '' ) ); ?></p>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
  </div>
</article>
