<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$id = get_the_ID();
$price = bp_meta( $id, '_bp_price', '' ); $unit = bp_meta( $id, '_bp_unit', '' );
$avail = bp_meta( $id, '_bp_availability', '' ); $badge = bp_meta( $id, '_bp_badge', '' );
$cats = get_the_terms( $id, 'bp_product_category' );
$catname = ( $cats && ! is_wp_error( $cats ) ) ? $cats[0]->name : '';
?>
<article class="bp-card bp-product-card">
  <a class="bp-card-media" href="<?php the_permalink(); ?>">
    <?php the_post_thumbnail( 'bp-card' ); ?>
    <?php if ( $badge ) : ?><span class="bp-badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?>
    <?php if ( $avail ) : ?><span class="bp-avail"><?php echo esc_html( $avail ); ?></span><?php endif; ?>
  </a>
  <div class="bp-card-body">
    <?php if ( $catname ) : ?><p class="bp-eyebrow"><?php echo esc_html( $catname ); ?></p><?php endif; ?>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <p class="bp-price-row"><?php if ( $price ) : ?><span class="bp-price"><?php echo esc_html( $price ); ?></span><?php if ( $unit ) : ?><span class="bp-unit">/ <?php echo esc_html( $unit ); ?></span><?php endif; ?><?php else : ?><span class="bp-price"><?php esc_html_e( 'Price on request', 'brickpoint' ); ?></span><?php endif; ?></p>
    <p class="bp-card-cta">
      <a class="btn-dark btn-sm" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View Product', 'brickpoint' ); ?></a>
      <a class="btn-whatsapp btn-sm" target="_blank" rel="noopener" href="<?php echo esc_url( bp_whatsapp_url( bp_product_whatsapp_message( $id ) ) ); ?>"><?php esc_html_e( 'WhatsApp', 'brickpoint' ); ?></a>
    </p>
  </div>
</article>
