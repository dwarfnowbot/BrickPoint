<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function brickpoint_elementor_category( $elements_manager ) {
  $elements_manager->add_category( 'brickpoint', array( 'title' => __( 'BrickPoint', 'brickpoint' ), 'icon' => 'fa fa-cube' ) );
}
add_action( 'elementor/elements/categories_registered', 'brickpoint_elementor_category' );

function brickpoint_register_elementor_widgets( $widgets_manager ) {
  $dir = BRICKPOINT_DIR . '/elementor/widgets/';
  $widgets = array(
    'product-grid.php', 'product-categories.php', 'product-price.php',
    'whatsapp-button.php', 'video-grid.php', 'video-card.php',
    'project-grid.php', 'location-cards.php', 'social-links.php',
  );
  foreach ( $widgets as $file ) {
    $path = $dir . $file;
    if ( file_exists( $path ) ) { require_once $path; }
  }
  $classes = array(
    'BrickPoint_Product_Grid', 'BrickPoint_Product_Categories', 'BrickPoint_Product_Price',
    'BrickPoint_WhatsApp_Button', 'BrickPoint_Video_Grid', 'BrickPoint_Video_Card',
    'BrickPoint_Project_Grid', 'BrickPoint_Location_Cards', 'BrickPoint_Social_Links',
  );
  foreach ( $classes as $class ) {
    if ( class_exists( $class ) ) { $widgets_manager->register( new $class() ); }
  }
}
add_action( 'elementor/widgets/register', 'brickpoint_register_elementor_widgets' );
