<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function brickpoint_register_post_types() {
  register_post_type( 'bp_product', array(
    'labels' => array(
      'name' => __( 'Products', 'brickpoint' ),
      'singular_name' => __( 'Product', 'brickpoint' ),
      'add_new_item' => __( 'Add New Product', 'brickpoint' ),
      'edit_item' => __( 'Edit Product', 'brickpoint' ),
    ),
    'public' => true, 'has_archive' => true,
    'rewrite' => array( 'slug' => 'products' ),
    'menu_icon' => 'dashicons-building',
    'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions', 'page-attributes' ),
    'show_in_rest' => true,
  ) );
  register_post_type( 'bp_video', array(
    'labels' => array(
      'name' => __( 'Videos', 'brickpoint' ),
      'singular_name' => __( 'Video', 'brickpoint' ),
      'add_new_item' => __( 'Add New Video', 'brickpoint' ),
      'edit_item' => __( 'Edit Video', 'brickpoint' ),
    ),
    'public' => true, 'has_archive' => true,
    'rewrite' => array( 'slug' => 'videos' ),
    'menu_icon' => 'dashicons-video-alt3',
    'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
    'show_in_rest' => true,
  ) );
  register_post_type( 'bp_project', array(
    'labels' => array(
      'name' => __( 'Projects', 'brickpoint' ),
      'singular_name' => __( 'Project', 'brickpoint' ),
      'add_new_item' => __( 'Add New Project', 'brickpoint' ),
      'edit_item' => __( 'Edit Project', 'brickpoint' ),
    ),
    'public' => true, 'has_archive' => true,
    'rewrite' => array( 'slug' => 'projects' ),
    'menu_icon' => 'dashicons-portfolio',
    'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions', 'page-attributes' ),
    'show_in_rest' => true,
  ) );
  register_post_type( 'bp_location', array(
    'labels' => array(
      'name' => __( 'Locations', 'brickpoint' ),
      'singular_name' => __( 'Location', 'brickpoint' ),
      'add_new_item' => __( 'Add New Location', 'brickpoint' ),
      'edit_item' => __( 'Edit Location', 'brickpoint' ),
    ),
    'public' => true, 'has_archive' => true,
    'rewrite' => array( 'slug' => 'locations' ),
    'menu_icon' => 'dashicons-location-alt',
    'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
    'show_in_rest' => true,
  ) );
}
add_action( 'init', 'brickpoint_register_post_types' );
