<?php
/**
 * BrickPoint theme bootstrap.
 *
 * @package BrickPoint
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'BRICKPOINT_VERSION', '1.0.0' );
define( 'BRICKPOINT_DIR', get_template_directory() );
define( 'BRICKPOINT_URI', get_template_directory_uri() );

require BRICKPOINT_DIR . '/inc/setup.php';
require BRICKPOINT_DIR . '/inc/enqueue.php';
require BRICKPOINT_DIR . '/inc/helpers.php';
require BRICKPOINT_DIR . '/inc/template-functions.php';
require BRICKPOINT_DIR . '/inc/post-types.php';
require BRICKPOINT_DIR . '/inc/taxonomies.php';
require BRICKPOINT_DIR . '/inc/meta-fields.php';
require BRICKPOINT_DIR . '/inc/whatsapp.php';
require BRICKPOINT_DIR . '/inc/video-functions.php';
require BRICKPOINT_DIR . '/inc/project-functions.php';
require BRICKPOINT_DIR . '/inc/customizer.php';
require BRICKPOINT_DIR . '/inc/elementor.php';
require BRICKPOINT_DIR . '/inc/elementor-widgets.php';
require BRICKPOINT_DIR . '/inc/admin.php';
