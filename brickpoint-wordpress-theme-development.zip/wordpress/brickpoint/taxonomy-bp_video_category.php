<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<div class="bp-pagehead"><div class="bp-container">
  <p class="bp-eyebrow"><?php esc_html_e( 'Video Category', 'brickpoint' ); ?></p>
  <h1><?php single_term_title(); ?></h1>
  <?php the_archive_description( '<p>', '</p>' ); ?>
</div></div>
<div class="bp-container bp-section"><div class="bp-grid cols-3">
  <?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/video-card' ); endwhile; ?>
</div><?php brickpoint_pagination(); ?></div>
<?php get_footer(); ?>
