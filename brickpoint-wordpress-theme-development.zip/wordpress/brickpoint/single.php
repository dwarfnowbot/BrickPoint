<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); ?>
<article <?php post_class( 'bp-single' ); ?>>
  <div class="bp-pagehead"><div class="bp-container">
    <h1><?php the_title(); ?></h1>
    <?php brickpoint_posted_meta(); bp_breadcrumbs(); ?>
  </div></div>
  <div class="bp-container bp-narrow bp-section">
    <?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'bp-hero', array( 'class' => 'bp-single-img' ) ); endif; ?>
    <div class="bp-entry"><?php the_content(); ?></div>
    <?php the_tags( '<p class="bp-tags">', ', ', '</p>' ); ?>
    <?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?>
  </div>
  <div class="bp-container"><?php brickpoint_related_posts(); ?></div>
</article>
<?php endwhile; get_footer(); ?>
