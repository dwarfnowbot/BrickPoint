<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<div class="bp-pagehead"><div class="bp-container">
  <h1><?php printf( esc_html__( 'Search: %s', 'brickpoint' ), esc_html( get_search_query() ) ); ?></h1>
  <?php get_search_form(); ?>
</div></div>
<div class="bp-container bp-section">
  <?php if ( have_posts() ) : ?><div class="bp-grid cols-3">
    <?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content' ); endwhile; ?>
  </div><?php brickpoint_pagination(); else : ?>
    <p><?php esc_html_e( 'No results found. Try different keywords.', 'brickpoint' ); ?></p>
  <?php endif; ?>
</div>
<?php get_footer(); ?>
